### SummonEnderChestSpell (irons_spellbooks:summon_ender_chest)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 25 | 基础魔力消耗 |
| manaCostPerLevel | INT | 1 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 1 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 5.0 | 默认冷却时间 (秒) |
| allowNonPlayerCaster | BOOLEAN | false | 是否允许非玩家施放 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
