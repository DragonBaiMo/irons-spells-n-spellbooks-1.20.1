### AcidOrbSpell (irons_spellbooks:acid_orb)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 30 | 基础魔力消耗 |
| manaCostPerLevel | INT | 3 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 1 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 0 | 每级技能威力增量 |
| castTime | INT | 15 | 施法时间 (tick) |
| cooldown | DOUBLE | 15.0 | 默认冷却时间 (秒) |
| radiusPerPower | DOUBLE | 3.0 | 每点威力对应的爆炸半径 |
| rendAmplifierOffset | INT | 2 | 破甲等级基础偏移值 |
| rendDurationSecondsPerPower | DOUBLE | 20.0 | 每点威力附加的破甲持续时间 (秒) |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
