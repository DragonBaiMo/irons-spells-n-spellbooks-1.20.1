### FirecrackerSpell (irons_spellbooks:firecracker)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 20 | 基础魔力消耗 |
| manaCostPerLevel | INT | 2 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 4 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 1.5 | 默认冷却时间 (秒) |
| rangeBase | INT | 15 | 基础射程 |
| rangePerPower | FLOAT | 2.0 | 每点威力增加射程 |
| damageScale | FLOAT | 1.0 | 伤害系数 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
