### BurningDashSpell (irons_spellbooks:burning_dash)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 20 | 基础魔力消耗 |
| manaCostPerLevel | INT | 2 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 1 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 10.0 | 默认冷却时间 (秒) |
| damageBase | INT | 5 | 基础伤害 |
| damagePerPower | DOUBLE | 1.0 | 每点威力附加伤害 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
