### SunbeamSpell (irons_spellbooks:sunbeam)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 40 | 基础魔力消耗 |
| manaCostPerLevel | INT | 10 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 24 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 3 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 20.0 | 默认冷却时间 (秒) |
| targetRange | DOUBLE | 48.0 | 目标选取距离 |
| damageMultiplier | DOUBLE | 0.5 | 伤害倍率 (基于技能威力) |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
