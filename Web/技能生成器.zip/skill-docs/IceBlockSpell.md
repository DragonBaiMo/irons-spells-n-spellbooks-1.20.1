### IceBlockSpell (irons_spellbooks:ice_block)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 40 | 基础魔力消耗 |
| manaCostPerLevel | INT | 10 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 14 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 2 | 每级技能威力增量 |
| castTime | INT | 30 | 施法时间 (tick) |
| cooldown | DOUBLE | 15.0 | 默认冷却时间 (秒) |
| airTimeNoTarget | INT | 25 | 未锁定目标时悬空时长 (tick) |
| airTimeTarget | INT | 35 | 锁定目标时悬空时长 (tick) |
| damageMultiplier | FLOAT | 1.0 | 伤害威力倍率 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
