### GuidingBoltSpell (irons_spellbooks:guiding_bolt)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 20 | 基础魔力消耗 |
| manaCostPerLevel | INT | 5 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 6 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 8.0 | 默认冷却时间 (秒) |
| damageScale | FLOAT | 0.5 | 伤害系数 |
| markDurationSeconds | INT | 25 | 标记持续时间 (秒) |
| projectileSpeed | FLOAT | 1.0 | 投射物速度系数 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
