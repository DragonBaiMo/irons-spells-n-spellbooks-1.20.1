### CloudOfRegenerationSpell (irons_spellbooks:cloud_of_regeneration)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 10 | 基础魔力消耗 |
| manaCostPerLevel | INT | 3 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 2 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 200 | 施法时间 (tick) |
| cooldown | DOUBLE | 35.0 | 默认冷却时间 (秒) |
| healPerPower | DOUBLE | 0.5 | 每点威力对应的治疗量 |
| radius | DOUBLE | 5.0 | 治疗半径 |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
