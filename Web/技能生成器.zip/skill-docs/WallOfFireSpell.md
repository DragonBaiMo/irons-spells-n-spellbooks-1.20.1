### WallOfFireSpell (irons_spellbooks:wall_of_fire)


| 参数名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| manaCost / baseManaCost | INT | 30 | 基础魔力消耗 |
| manaCostPerLevel | INT | 5 | 每级魔力消耗增量 |
| power / baseSpellPower | INT | 4 | 基础技能威力 |
| levelScaling / spellPowerPerLevel | INT | 1 | 每级技能威力增量 |
| castTime | INT | 0 | 施法时间 (tick) |
| cooldown | DOUBLE | 30.0 | 默认冷却时间 (秒) |
| maxWallLength | DOUBLE | 25.0 | 火墙最大总长度 |
| recastCount | INT | 3 | 可放置锚点次数 |
| recastCooldownTicks | INT | 40 | 锚点窗口时长 (tick) |

**说明**: 参数可在管理员通道中通过 SpellParameters 进行覆盖。
